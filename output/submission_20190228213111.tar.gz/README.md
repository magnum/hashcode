# hashcode2019

### readline issue w/ ruby/rbenv
https://gist.github.com/wbotelhos/46c37807c834ccb5bb406e426adfe347

### running
run with:
`ruby runner.rb FILENAME`
example:
`ruby runner.rb b_lovely_landscapes.txt`


