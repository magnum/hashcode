# hashcode2021

### readline issue w/ ruby/rbenv
https://gist.github.com/wbotelhos/46c37807c834ccb5bb406e426adfe347

### running
run with:
`ruby runner.rb`
files specified in runner.rb as array
output will be in ./output folder

manual save submission
`tar cvzf output/submission_$(date +"%Y%m%d%H%M%S").tar.gz  --exclude --exclude .git --exclude "*.txt" --exclude="./output/*" ./`



