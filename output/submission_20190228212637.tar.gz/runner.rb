require './parser.rb'

object = Parser.new
object.run ARGV